#Input request
mnt_height = int(input("What is the height of the mountain? "))

#Expression form of if
print("Really small mountain.") if mnt_height == 141 else print("Not the smallest mountain in the world.")

