#Initiate counter variable
counter = 0

#increment counter by 1 until counter is 20
while counter < 20:
	counter += 1
	
#Infinite while loop
while True:
	print(counter)
